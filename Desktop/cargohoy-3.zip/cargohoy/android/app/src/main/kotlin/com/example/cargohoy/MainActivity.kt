package com.example.cargohoy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
