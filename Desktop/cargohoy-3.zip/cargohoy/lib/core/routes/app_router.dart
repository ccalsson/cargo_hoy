class AppRouter {
  static const String splash = '/';
  static const String login = '/login';
  static const String register = '/register';
  static const String roleSelection = '/role-selection';
  static const String home = '/home';
  static const String profile = '/profile';
  static const String settings = '/settings';
} 